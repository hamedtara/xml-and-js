# Assignment

- Expand your activity
- Add radio buttons to filter form to show genres with playlist only or without playlists
- Attach screenshots of filter result
