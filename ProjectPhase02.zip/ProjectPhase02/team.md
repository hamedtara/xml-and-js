Hamed tara - n01540404
Garry mittal - n01552883
